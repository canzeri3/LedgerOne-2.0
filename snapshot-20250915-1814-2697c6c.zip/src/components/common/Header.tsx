'use client'

export default function Header() {
  return null
}

